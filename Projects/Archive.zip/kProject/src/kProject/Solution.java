package kProject;

public class Solution {

	public static void main(String[] args) {
		int[] A = {4, 3, 2, 5, 1, 1};
//		int[] A = {1, 3, -3};
		Solution s=new Solution();
//		s.solutionB(A);
		System.out.println(s.solutionB(A));

	}
	
	   public static int solutionB(int[] A) {
	        if (A == null || A.length <= 0) {
	            return 0;
	        }
	        int[] B = new int[A.length]; 

	        int kthMax = 0;
	        for (int i = 0; i < A.length; i++) {
	        	System.out.println(kthMax);
	            if (A[i] > kthMax) {
	                kthMax = A[i];
	            }
	            B[i] = kthMax;
	        }
	        
//	        for (int z = 0; z < B.length; z++) {
//	        	System.out.println("-----");
//	        		System.out.print("   "+B[z]+"   ");
//	        		System.out.println("");
//		    System.out.println("-----");
//	        }
//	        
	        
	        	System.out.println("********");
	        int maxAbs = 0;
	        int nthMin = A[A.length - 1];
	        for (int j = A.length - 1; j >= 0; j--) {
	        	System.out.println(nthMin);
	            if (A[j] < nthMin) {
	                nthMin = A[j];
	            }
	            int abs = Math.abs(B[j] - nthMin);
	            if (abs > maxAbs) {
	                maxAbs = abs;
	            }
	        }
	        

	        
	        return maxAbs;
	    }

}
