package kProject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class NewSolution {

	public static void main(String[] args) {
//		int[] A = {4, 3, 2, 5, 1, 1};
		int[] A = {1, 3, -3};
		System.out.println(solutionB(A)); 
		//https://github.com/xuelianhan/basic-algos/blob/master/src/main/java/org/ict/algorithm/leetcode/AnnieTestTwo.java
	}
	
	public static int solutionB(int[] A) {
		int sol=0;
		//find K values;
		int k=A.length-1;
		List finalArray=new ArrayList();
		
		for(int i=0;i<k;i++) {
			List l=new ArrayList();
			List r=new ArrayList();
			for(int j=0;j<A.length;j++) {
				if(j<=i) {
					l.add(A[j]);
				}else {
					r.add(A[j]);
				}
			}
			
//			System.out.println("");
//			for (Object object : l) {
//				System.out.print(" "+(int)object+"");
//			}
//			System.out.println("");
//			for (Object object : r) {
//				System.out.print(" "+(int)object+"");
//			}
			
			
			int maxL=(int) Collections.max(l);
			int maxR=(int) Collections.max(r);
			int abs=Math.abs(maxL-maxR);
			finalArray.add(abs);
			
		}
		
		
	
		
		return (int) Collections.max(finalArray);
		
	}

}
