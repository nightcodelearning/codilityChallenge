package zipInteger;

public class MainZip {

	public static void main(String[] args) {
		
		MainZip m=new MainZip();
//		 For example, the decimal zip of 12 and 56 is 1526.
//		 The decimal zip of 56 and 12 is 5162.
//		 The decimal zip of 12345 and 678 is 16273845.
											
//		 The decimal zip of 123 and 67890 is 16273890.	
//											16273890		
		int num=m.solution(12345, 67899);
	//	int num=m.solution(100_000_000, 100_000_000);
//		int num=m.solution(56, 12);
		//int num=m.solution(12345, 115);

		
		System.out.println(num);

	}
	
	
	int solution(int A, int B) {
		int result=100_000_000;
	
		String aPrima = String.valueOf(A);
		String bPrima = String.valueOf(B);
		System.out.println("A = "+aPrima);
		System.out.println("B = "+bPrima);
		int aLen=aPrima.length();
		int bLen = bPrima.length();
		
		String temp="";
		
		for (int i = 0; (i < aLen) || (i < bLen); i++) {
			if(i<aLen) {
				temp+=aPrima.charAt(i);
			}
			if(i<bLen) {
				temp += bPrima.charAt(i);
			}
			System.out.println(temp);
			if(Integer.parseInt(temp) > result) {
				return -1;
			}
		} 
		/*Long sol = Long.parseLong(temp);
		if(sol > result) {
			return -1;
		}
		//https://github.com/LucijaGregov/codility/blob/master/zip_decimal.rb
		return Math.toIntExact(sol);*/
		return Integer.parseInt(temp);
			
	}

}
