package zipInteger;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int val=1;
		System.out.println(val>=0&&val<4);
	
	}

}
