package empleoProject1;

import java.util.ArrayList;
import java.util.List;

public class NewSolutionSlice {

	public static void main(String[] args) {
		

//		int [] A= new int[] {1, 3, 5, 7, 9,11};	
//		int [] A= new int[] {2, 2, 3, 4, 5};
//		int [] A= new int[] {2, 4, 6, 8, 10};
//		int [] A= new int[] {1, 2, 3, 4};
//		int [] A= new int[] {3, -1, -5, -9};
//		int [] A= new int[] {7, 7, 7, 7};
		int [] A= new int[] {1, 1, 2, 5, 7};
		
		
		
		System.out.println(solution(A));
	}
	
	public static int solution(int[] A) {
		List temp=new ArrayList();
		
		int z=0;
		
		List lista=new ArrayList();
		while(z<=A.length-1) {
			for (int i = 0; i <= z; i++) {
				List lista2=new ArrayList();
				for (int j = i; j <= z; j++) {
					lista2.add(A[j]);
				}
				temp.add(lista2);	
			}
			z++;
		}
		
		
		
		
		

		List listaFinal=new ArrayList();
		int cont=0;
		for (int i=0; i<temp.size();i++) {
			List listaInterna=(List) temp.get(i);
			if(listaInterna.size()>=3) {
				boolean b=isAllArithmetic(listaInterna);
				if(b) {
					cont++;
				}
			}
			
		}
		return cont;

		
	}
	
	
	private static boolean isAllArithmetic(List list) {
		boolean isArithmetic = true;
		for (int i = 0; (i < list.size()-2) && isArithmetic; i++) {
			isArithmetic = isArithmetic && isArithmetic((int)list.get(i), (int)list.get(i+1), (int)list.get(i+2));
		}

		return isArithmetic;
	}
	
	private static boolean isArithmetic(int a, int b, int c) {
		if ((a - b) == (b - c)) {
			return true;
		}
		return false;
	}
	
	


}
