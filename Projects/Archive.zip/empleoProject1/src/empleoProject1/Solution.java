package empleoProject1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Solution {

	public static void main(String[] args) {
		int [] A= new int[] {2, 2, 3, 4, 5};		
		System.out.println("Count "+ getArithmeticSlice(A));
	}
	
	public static int getArithmeticSlice(int [] A){
		if(A.length < 3) {
			return 0;	
		}
		int count = 0;
		for (int j = 0; j < A.length-2; j++) {
			for (int i = j+3; i <= A.length; i++) {
				//System.out.println(j+"----"+i);

				int[] grp = Arrays.copyOfRange(A, j, i);
				//System.out.print(" Size: "+grp.length);
				//System.out.println(" last: "+grp[grp.length-1]);

				if (isAllArithmetic(grp)) {
					count++;
				}
			}			
		}
		return count;
	}
	
	private static boolean isAllArithmetic(int [] list) {
		boolean isArithmetic = true;
		for (int i = 0; (i < list.length-2) && isArithmetic; i++) {
			isArithmetic = isArithmetic && isArithmetic(list[i], list[i+1], list[i+2]);
		}
		/*int i = 0; do {
			isArithmetic = isArithmetic && isArithmetic(list[i], list[i+1], list[i+2]);
			i++;
		} while (i < list.length-2 && !isArithmetic);
		*/
		System.out.println(isArithmetic);

		return isArithmetic;
	}
	private static boolean isArithmetic(int a, int b, int c) {
		System.out.println(a +" " +b +" "+ c);
		//System.out.println(a+" - "+ b +" = "+(a-b));
		//System.out.println(b+" - "+ c +" = "+(b-c));
		if ((a - b) == (b - c)) {
			return true;
		}
		return false;
	}
	
//	public int numberOfArithmeticSlices(int[] A) {
//		int len=A.length; 
//		System.out.println(len);
//		if(len>=3) {
//			 for (int i = 0; i < A.length; i++) {
//				 
//				 int myVal=A[i];
//			     int next=A[i+1];
//			     int diff=next-myVal;
//			     System.out.println(diff);
//			     
//			     
//			     
//			}
//			 return 1;
//		 }else {
//			 return 0;
//		 }
//		
		
//	        List lista=new ArrayList();
//	        
//	       
//	        for (int i = 0; i < A.length; i++) {
//	        		myVal=A[i];
//	        		if()
//	        	
//				System.out.println(A[i]);
//			}
//	        
//	        int value=0;
//	        return lista.size();
//	}
	

}
