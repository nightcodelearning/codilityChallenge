package empleoProject1;

public class Done {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int [] A= new int[] {1, 2, 3, 4};
		int [] A= new int[] {8, 8, 9, 10, 11};		

		Done done=new Done();
		
		int x=done.sliceOfAP(A);
		System.out.println(x);

	}
	
	
	public int sliceOfAP(int[] A){
		int n = A.length;
		if(n < 3) return 0;	//mininum length of arithmetic slice is 3
		
		int start = 0;	//start of a slice
		
		int numOfSlices = 0;	//answer we want
		
		while(start < n-2){
			int end = start+1;	//end of a slice
			int diff = A[end] - A[start];	//diff of the arithmetic
			
			//extend until arithmetic condition fails
			while(end < n-1 && A[end+1] - A[end] == diff){
				end++;
			}
			
			int lenOfSlice = end - start + 1;	//length of the found arightmetic slice
			
			//valid slice must have at least 3 number
			if(lenOfSlice >= 3){
				
				//For an arithmetic progression with length n, where n>3, the number of slices it can form is
				// (n-2)*(n-1)/2. For example, if n = 5, it has 3 slices with length 3, 2 slices with length 4, 
				// and 1 slice with length 5.
				numOfSlices += ((lenOfSlice-2)*(lenOfSlice-1)/2);
			}
			
			//Arithmetic progression will not overlap, so move start to end
			start = end;
		}
		
		//consider overflow
		return (numOfSlices > 1000000000) ? -1 : numOfSlices;
	}
	
	
	

}
